This is a, possibly incomplete, list of Jil contributors.
Names (N) are in alphabetic order, emails (E) and websites (W) are optional.
When you submit a pull request, you may also modify this file
if you so desire.

Code need not be directly merged to merit inclusion in this file.
Reference implementations, significant and clear bug reports, etc. 
are also sufficient.

This file is modeled on the [Linux CREDITS file](https://github.com/torvalds/linux/blob/master/CREDITS).

====

N: Kevin Montrose  
E: kevin.montrose@stackoverflow.com  
W: http://kevinmontrose.com/  

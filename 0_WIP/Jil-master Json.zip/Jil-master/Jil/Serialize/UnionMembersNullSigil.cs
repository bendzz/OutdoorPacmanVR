﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jil.Serialize
{
    // just used to signal that a union was all null
    sealed class UnionMembersNullSigil
    {
    }
}

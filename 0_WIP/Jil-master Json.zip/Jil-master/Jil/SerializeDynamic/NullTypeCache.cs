﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jil.SerializeDynamic
{
    // just a placeholder for reused parts of Jil that expect a type cache
    static class NullTypeCache<T>
    {
    }
}
